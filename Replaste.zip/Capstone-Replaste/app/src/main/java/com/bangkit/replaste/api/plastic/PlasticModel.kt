package com.bangkit.replaste.api.plastic

data class PlasticModel(
    val email: String,
)
