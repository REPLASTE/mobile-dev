package com.bangkit.replaste.ui.guide

data class GuideModel(
    val title: String,
    val description: String,
    val emoji: String,
    val category: String
)