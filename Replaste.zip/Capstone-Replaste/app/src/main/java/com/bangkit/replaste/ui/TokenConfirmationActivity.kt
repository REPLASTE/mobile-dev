package com.bangkit.replaste.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import com.bangkit.replaste.R
import com.bangkit.replaste.api.ApiClient
import com.bangkit.replaste.api.auth.MessageResponse
import com.bangkit.replaste.api.auth.ResetPasswordConfirmationRequest
import com.bangkit.replaste.databinding.ActivityTokenConfirmationBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TokenConfirmationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTokenConfirmationBinding
    private var loadingDialog: AlertDialog? = null
    private var successDialog: AlertDialog? = null
    private var newPassword: String = ""
    private var token: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTokenConfirmationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.savePasswordButton.setOnClickListener {
            validateAndSavePassword()
        }

        binding.confirmTokenButton.setOnClickListener {
            validateAndConfirmToken()
        }

        binding.toolbar.setNavigationOnClickListener {
            redirectToLogin()
        }

    }

    private fun validateAndSavePassword() {
        newPassword = binding.newPasswordEditText.text.toString()
        require(newPassword.isNotEmpty()) { "Password tidak boleh kosong" }

        showLoadingDialog()

        binding.loadingText.visibility = View.GONE
        binding.title.visibility = View.GONE
        binding.tokenContainer.visibility = View.VISIBLE
        binding.newPasswordInputLayout.visibility = View.GONE
        binding.savePasswordButton.visibility = View.GONE
        Handler(Looper.getMainLooper()).postDelayed({
            dismissLoadingDialog()
        }, 1500)
    }

    private fun validateAndConfirmToken() {
        token = binding.tokenEditText.text.toString()
        require(token.isNotEmpty()) { "Token tidak boleh kosong" }

        val resetRequest = ResetPasswordConfirmationRequest(password = newPassword)

        showLoadingDialog()

        ApiClient.authService.resetPasswordConfirmation(token, resetRequest)
            .enqueue(object : Callback<MessageResponse> {
                override fun onResponse(
                    call: Call<MessageResponse>,
                    response: Response<MessageResponse>
                ) {
                    dismissLoadingDialog()

                    if (response.isSuccessful) {
                        showSuccessAnimation()
                    } else {
                        val errorMessage = when (response.code()) {
                            400 -> "Token tidak valid atau sudah kadaluarsa"
                            401 -> "Anda tidak memiliki izin untuk melakukan ini"
                            404 -> "Halaman tidak ditemukan"
                            else -> response.body()?.message ?: "Terjadi kesalahan. Silakan coba lagi."
                        }
                        showErrorDialog(errorMessage)
                    }
                }

                override fun onFailure(call: Call<MessageResponse>, t: Throwable) {
                    dismissLoadingDialog()
                    showErrorDialog("Kesalahan jaringan. Silakan periksa koneksi Anda.")
                }
            })
    }

    private fun showLoadingDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_save_loading, null)
        val animationView = view.findViewById<LottieAnimationView>(R.id.animationView)
        animationView.setAnimation(R.raw.loading_animation)
        animationView.playAnimation()

        loadingDialog = AlertDialog.Builder(this)
            .setView(view)
            .setCancelable(false)
            .create()

        loadingDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        loadingDialog?.show()
    }

    private fun dismissLoadingDialog() {
        loadingDialog?.dismiss()
    }

    private fun showSuccessAnimation() {
        val view = layoutInflater.inflate(R.layout.dialog_success_reset_confirmation, null)
        successDialog = AlertDialog.Builder(this)
            .setView(view)
            .setCancelable(false)
            .create()

        val successAnimationView = view.findViewById<LottieAnimationView>(R.id.successAnimationView)
        successAnimationView.setAnimation(R.raw.success_checkmark)
        successAnimationView.playAnimation()

        successAnimationView.addAnimatorListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                super.onAnimationEnd(animation)
                Handler(Looper.getMainLooper()).postDelayed({
                    redirectToLogin()
                }, 1500)
            }
        })

        successDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        successDialog?.show()
    }

    private fun showErrorDialog(message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setMessage(message)
            .setCancelable(false)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        val alert = builder.create()
        alert.show()
    }

    private fun redirectToLogin() {
        val intent = Intent(this, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
        finish()
    }
}