package com.bangkit.replaste.ui.location

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.airbnb.lottie.LottieAnimationView
import com.bangkit.replaste.R
import com.bangkit.replaste.api.ApiClient
import com.bangkit.replaste.api.auth.RecyclingLocation
import com.bangkit.replaste.databinding.ActivityRecyclingLocationBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RecyclingLocationsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecyclingLocationBinding
    private lateinit var locationsAdapter: RecyclingLocationsAdapter
    private var loadingDialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecyclingLocationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        fetchRecyclingLocations()
        setupSwipeRefresh()

        binding.toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefreshLayout.setOnRefreshListener { fetchRecyclingLocations() }
    }

    private fun setupRecyclerView() {
        locationsAdapter = RecyclingLocationsAdapter(onMapClickListener = { location ->
            openGoogleMaps(location.gmapsLink)
        })
        binding.rvRecyclingLocations.apply {
            layoutManager = LinearLayoutManager(this@RecyclingLocationsActivity)
            adapter = locationsAdapter
        }
    }


    private fun fetchRecyclingLocations() {
        binding.swipeRefreshLayout.isRefreshing = true
        showLoadingDialog()

        ApiClient.menuService.getListLocation().enqueue(object : Callback<List<RecyclingLocation>> {
            override fun onResponse(
                call: Call<List<RecyclingLocation>>, response: Response<List<RecyclingLocation>>
            ) {
                dismissLoadingDialog()
                binding.swipeRefreshLayout.isRefreshing = false
                if (response.isSuccessful) {
                    response.body()?.let { locations ->
                        locationsAdapter.submitList(locations)
                    } ?: run {
                        Toast.makeText(
                            this@RecyclingLocationsActivity,
                            "No locations found",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@RecyclingLocationsActivity,
                        "Failed to fetch locations",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<List<RecyclingLocation>>, t: Throwable) {
                dismissLoadingDialog()
                binding.swipeRefreshLayout.isRefreshing = false
                Toast.makeText(
                    this@RecyclingLocationsActivity,
                    "Network error: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun openGoogleMaps(location: String) {
        try {
            val gmmIntentUri = Uri.parse(location)
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            mapIntent.setPackage("com.google.android.apps.maps")

            if (mapIntent.resolveActivity(packageManager) != null) {
                startActivity(mapIntent)
            } else {
                openInBrowser(location)
            }
        } catch (e: ActivityNotFoundException) {
            openInBrowser(location)
        }
    }


    private fun openInBrowser(url: String) {
        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(browserIntent)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Cannot open location. Please ensure you have a map app or browser.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun showLoadingDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_save_loading, null)
        val animationView = view.findViewById<LottieAnimationView>(R.id.animationView)
        animationView.setAnimation(R.raw.loading_animation)
        animationView.playAnimation()

        loadingDialog = AlertDialog.Builder(this).setView(view).setCancelable(false).create()

        loadingDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        loadingDialog?.show()
    }

    private fun dismissLoadingDialog() {
        loadingDialog?.dismiss()
    }
}