package com.bangkit.replaste.api.menu

import com.bangkit.replaste.api.ApiConstants
import com.bangkit.replaste.api.auth.RecyclingLocation
import retrofit2.Call
import retrofit2.http.GET

interface MenuService {
    @GET(ApiConstants.LIST_TYPE_PLASTIC)
    fun getListPlastic(): Call<List<PlasticTypeModel>>

    @GET(ApiConstants.LIST_LOCATION_PLASTIC)
    fun getListLocation(): Call<List<RecyclingLocation>>
}