package com.bangkit.replaste.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import com.bangkit.replaste.R
import com.bangkit.replaste.api.ApiClient
import com.bangkit.replaste.api.auth.MessageResponse
import com.bangkit.replaste.api.auth.ResetPasswordRequest
import com.bangkit.replaste.databinding.ActivityResetPasswordBinding
import com.bangkit.replaste.utils.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ResetPasswordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityResetPasswordBinding
    private var loadingDialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResetPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
        setupUI()
    }

    private fun setupUI() {
        binding.resetButton.setOnClickListener {
            val email = binding.emailEditText.text.toString().trim()

            if (!NetworkUtils.isInternetAvailable(this)) {
                showNoInternetDialog()
                return@setOnClickListener
            }

            if (isValidEmail(email)) {
                showLoadingDialog()
                performPasswordReset(email)
            } else {
                binding.emailEditText.error = "Invalid email format"
            }
        }
    }

    private fun performPasswordReset(email: String) {
        val request = ResetPasswordRequest(email = email)
        ApiClient.authService.requestPasswordReset(request)
            .enqueue(object : Callback<MessageResponse> {
                override fun onResponse(
                    call: Call<MessageResponse>,
                    response: Response<MessageResponse>
                ) {
                    dismissLoadingDialog()

                    if (response.isSuccessful) {
                        showSuccessAnimation()
                    } else {
                        val errorMessage = response.body()?.message
                            ?: "Failed to send reset link. Please try again."
                        showErrorDialog(errorMessage)
                    }
                }

                override fun onFailure(call: Call<MessageResponse>, t: Throwable) {
                    dismissLoadingDialog()
                    showErrorDialog("Network error. Please check your connection.")
                }
            })
    }

    private fun showLoadingDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_save_loading, null)
        val animationView = view.findViewById<LottieAnimationView>(R.id.animationView)
        animationView.setAnimation(R.raw.loading_animation)
        animationView.playAnimation()

        loadingDialog = AlertDialog.Builder(this)
            .setView(view)
            .setCancelable(false)
            .create()

        loadingDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        loadingDialog?.show()
    }

    private fun dismissLoadingDialog() {
        loadingDialog?.dismiss()
    }

    private fun showSuccessAnimation() {
        binding.emailInputLayout.visibility = View.GONE
        binding.emailEditText.visibility = View.GONE
        binding.resetButton.visibility = View.GONE

        val successDialog = AlertDialog.Builder(this)
            .setView(R.layout.dialog_success)
            .setCancelable(false)
            .create()

        successDialog.setOnShowListener {
            val successAnimationView = successDialog.findViewById<LottieAnimationView>(R.id.successAnimationView)
            successAnimationView?.setAnimation(R.raw.success_checkmark)
            successAnimationView?.playAnimation()

            successAnimationView?.addAnimatorListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    CoroutineScope(Dispatchers.Main).launch {
                        delay(1500)
                        redirectToConfirmationToken()
                    }
                }
            })
        }

        successDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        successDialog.show()
    }

    private fun redirectToConfirmationToken() {
        val intent = Intent(this, TokenConfirmationActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
        finish()
    }


    private fun isValidEmail(email: String): Boolean {
        return email.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun showNoInternetDialog() {

        Toast.makeText(
            this,
            "No internet connection. Please check your network.",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showErrorDialog(message: String) {

        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

}